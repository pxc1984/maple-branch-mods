This mod would have not been possible without the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bugreporting

* **Hydromancerx**
* **Flint_N_Steel**

### Translators

* English advisors: **Ashantin**, **jjallie1**
* Czech: **DejFidOFF**
* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**
* Spanish: **Ruddi**, **SkyTheSkunny**
* Ukrainian: **DeanBro**, **justOmi**

### Resources

* The background image in the title card comes from [CSIRO](https://en.wikipedia.org/wiki/CSIRO)
* Fleece shape kindly provided by Ruddi

