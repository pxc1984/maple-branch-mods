# v1.6.0 - 2024-03-02 - More Fixes & Recipes

## Bug Fixes

* #128 - Shearing Angora goats failed due to wrong fleece code
* #124 - Sewingkit recipe references wrong type (Thanx, Naniganz!)

## New Features

* #130 - Items like fibers, fleece or woolen sacks can be found in cracked vessels
* #129 - Added some colored woolen sacks (brown, gray, white)
* #127 - Craft wooden beds with plain wool, too

## Compatibility With Other Mods

* #123 - Compatibility with ViesCraft Machines: Craft seat with wool cloth

## New Features

* #126 - Add incontainer textures for fleece so they show up in barrels and open crates

## Translations

* #125 - Update Ukrainian translation (Thanx, justOmi!)
* Add six missing German translations.

## Optimizations

* #128 - Remove legacy angora fleece and fiber items

# v1.5.6 - 2024-02-27 - More Wool Recipes

## Bug Fixes

* #122 - Some drifter patches were not disabled with drifter drops from config (Thanx, RemyDuron!)

## New Features

* #121 - Craft buckets with plain wool twine
* #120 - Craft sewing kits with plain wool twine

## Compatibility With Other Mods

* #110 - Compatibility with ViesCraft Machines: Craft cloth construction kits with wool cloth

# v1.5.5 - 2024-02-22 - BehaviorConfigs

## Bug Fixes

* #118 - Some patches did not yet use behaviorConfigs
* #119 - Shearing Sirohi goats produces only brown fleece, no yellow fleece

# v1.5.4 - 2024-02-17 - Depend No More

## Bug Fixes

* #117 - Fix the wrong dependency values in modinfo.json

# v1.5.3 - 2024-02-16 - More Storage

## New Features

* #116 - Cook candles with plain wool fibers, too
* #57 - Add woolen sacks for more inventory space

## Bug Fixes

* #115 - Valais goats produced light instead of white fleece when shearing
* #114 - Fix patching drops to work for 1.20.0..3 and 1.20.4 by using behaviorConfigs
* #112 - Making mordanted wool twine created mordanted flax twine
* #65 - Fix patching entity drops so it conflicts less with VS and other mods

## Tweaks and Balancing

* #103 - Tweak drops of fleece for dead goats to encourage shearing instead of killing

## Translations

* #113 - Update Spanish translation (Thanx, SkyTheSkunny!)

# v1.5.2 - 2024-02-08 - Fixes for Fleece

## Bug Fixes

* #104 - Fix white and mohair fleece processing not possible

## New Features

* #100 - Make drifter and dead animal drops configurable
* #101, #105, #107 - Add more recipes for wool items and clothing

## Tweaks and Balancing

* #106 - Tweak woolen sails recipe, add compatibility with Tailor's Delight
* #103 - Tweak drops of fleece for dead animals to encourage shearing instead of killing
* #103 - Tweak drops of fleece for surface drifters

## Compatibility With Other Mods

* #111 - Craft Tailor's Delight brushes with plain wool fibers

# v1.5.1 - 2024-01-20 - VS 1.20

## Bug Fixes

* #102 - Fix recipes for crafting dark checkered cloth from wool twine

## New Features

* #96 - Add generic white fleece & fibers
* #93 - Bears, foxes, hares and wolves drop fleece upon death

## Tweaks and Balancing

* #101 - Add more recipes using dark wool

# v1.5.0 - 2024-01-19 - VS 1.20

## New Features

* #98 - Add wool blocks (for chiseling)
* #97 - Add dark-colored wool twine and wool cloth
* #96 - Add some recipes for miner clothes
* #92 - Add recipe for warm woolen saddle blanket

## Compatibility With Other Mods

* #94 - Compatibility with Detailed Animals: Remove multiply-behaviour conflict
* #41 - Remove Hide & Fabric compatibility

## Compatibility With VS 1.20

* Change a few recipes so ingredient color matches new clothes color
* #90 - Fix a few more failing trader patches (Thanx, Bart!)
* #87 - Fix trader patches to work again
* #86 - Fix ore blasting bomb recipes
* #85 - Fix references to leather

## Bug Fixes

* #91 - Fix patches for Tailor's Delight and VS 1.20

# v1.4.1 - 2024-11-17 - Yak Shearing

## Bug Fixes

* #82 - Barrel recipes cannot use skipVariants
* #80 - Shearing animals dropped legacy fleece
* #79 - Tailor's Delight: spinning colored wool fibers produced plain wool twine
* #78 - Dead moose dropped fleece twice

## New Features

* #81 - Bleach colored wool fibers into plain wool fibers with lime water

## Compatibility With Other Mods

* #4 - The Critters Package: Yak can be sheared and give fleece

## Translations

* #77 - Fix display name of "yellow wool fibers"

# v1.4.0 - 2024-11-15 - More Wool Crafting

## Tweaks and Balancing

* #74 - Consolidate fleece and fibers into 9 colors for other mods to use

## Bug Fixes

* #75 - Fallow deer could not be sheared
* #73 - Deer, elk and moose can now bread, so you can actually sheer them.
	Compared to goats and sheep, gestation perios is 28 days (40% longer), cool down for pregnancy is twice as long

## Translations

* #76 - Update Czech translation (Thanx, DejFidOFF!)
* #76 - Update Spanish translation (Thanx, Ruddi!)
* #72 - Update Ukrainian translation (Thanx, DeanBro!)
* #71 - Update Japanese translation (Thanx, Macoto Hino!)

## Compatibility With Other Mods

* #70 - Craft & upgrade Better Crates with wool

## Tweaks and Balancing

* #64 - Make some ground storage collision boxes smaller

# v1.3.0 - 2024-11-09 - Wool Crafting

## Bug Fixes

* #68 - Fix error in drifter drop patches for metal scraps

## New Features

* #69 - Panning has a low chance to yield some wool fibers
* #67 - Craft VS sails with wool + 1 flaxwine
* #66 - Craft VS blasting bombs with wool
* #55 - Craft VS merchant clothes with wool

## Tweaks and Balancing

* #64 - Optimize texture sizes

## Compatibility With Other Mods

* #61 - Craft Primitive Survival rock blasting bombs with wool

# v1.2.2 - 2024-10-27 - More Features & Fixes

## Bugfixes

* #62 - Mordanted wool twine could not be crafted and could not be dyed brown
* #62 - Plain wool and plain wool twine could not be dyed brown

## New Features

* #61 - Wool (any color) and plain wool twine can be used to repair clothing
* #60 - Craft homespun clothing with wool

## Translations

* #63 - Update Spanish translation (Thanx, Ruddi!)
* #56 - Add Czech translation (Thanx, DejFidOFF!)

# v1.2.1 - 2024-10-20 - Knitting Needles

## Bugfixes

* #51 - Fix error about "TC" in Hide & Fabric patch
* #51 - Fix wrong paths in Tailor's Delight patches

## New Features

* #55 - Craft VS items with wool twine: plumb & square
* #55 - Craft more VS clothing items with wool cloth and twine
* #52 - Add knitting needles

## Tweaks and Balancing

* #54 - Clothing merchant sells a small amount of wool cloth
* #53 - Balance drifter drops, less for surface, more for deeper drifters
* #52 - Wool recipes use knitting needles instead of sticks or Tailor's Delight needles

# v1.2.0 - 2024-09-29 - Double Shearing

## Bugfixes

* #42 - Lightbrown deer fleece could not be washed
* #44 - Goat shearing values differed between server and client behavior

## New Features

* #50 - Add handbook guides on animal shearing, colored wool and knitting
* #47 - Add mordanted wool cloth and twine
* #45 - Add 12 differently colored wool fabrics (can be used panels)
* #45 - Add 12 differently colored wool cloth bundles
* #35 - Elk, deer, gazelles and moose are now shearable from generation 3 on
* #34 - Add eight different knitted warm, woolen sweaters
* #30 - Add wool-twine based recipes for commoner, survivor and peasent clothing
* #17 - Add ConfigLib support - toggle shearing of animal species

## Tweaks and Balancing

* #43 - Surface and deep drifters drop fleece instead of twine, tweak drop rates
* #31 - Tweak fleece drop rates for baby animals

## Compatibility With Other Mods

* #46 - Can convert Hide & Fabric wool items to Wool & More items
* #40 - Disable bighorn sheep old "wool" shearing when Hide & Fabric is installed
* #40 - Use ShearLib to provide a shearing behavior for all animals with fleece
* #32 - Add needles to wool-based recipes when Tailor's Delight is loaded
* #27 - Hide & Fabric domesticated adult bighorn sheep no longer basket catchable

## Optimizations

* Optimize trader patches by using `addeach`

# v1.1.0 - 2024-09-07 - Translations

## New Features

* #29 - Add darkbrown moose fleece and fibers
* #26 - Add plain and yellow gazelle fleece and fibers
* #12 - Add lightbrown and redbrown deer and elk fleece and fibers

## Tweaks and Balancing

* #27 - Adult bighorn sheep can no longer be catched with a basket trap
* #25 - Lessen fleece on short-haired goats to encourage seeking out long-haired animals like angora and mountain goats
* #25 - Reduce wool bonus per generation, but increase overall bonus

## Translations

* #28 - Add German translation for some Hide & Fabric texts
* #24 - Add Japanese translation (Thanx, Macoto Hino!)
* #23 - Add Ukrainian translation (Thanx, DeanBro!)

# v1.0.1 - 2024-09-01 - Corrections

## Tweaks and Balancing

* #20 - Under Hide & Fabric: Make bighorn sheep not spawn in lowlands

## Compatibility With Other Mods

* #21 - Wildcraft: Nuts & Fruits - Wool fleece, fiber and twine go into foraging baskets

# v1.0.0 - 2024-08-30 - First Clip

## New Features

* #19 - Drifters sometimes drop wool fibers, surface drifters can drop sticks
* #18 - Add some warmth values to VS clothing items
* #13 - Add wool twine in 12 different colors
* #11 - Commodities trader sells fleece, Artisan sells twine, clothing buys wool twine
* #9 - Add recipes for some woolen and/or warm clothing items from VS
* #2 - Add wool drops to VS animals: angora goats, musk ox and bighorn sheep
* #1 - Add various fleece, hair and wool fibers

## Compatibility With Other Mods

* #16 - Wildcraft: Use walnut black and spindle red dye to dye wool twine
* #10 - Hide & Fabric: Sheep drop fleece instead of wool
* #10 - Hide & Fabric: Domesticated adult goats can be sheered for fleece
* #5 - Domestic Animal trader sells some fleece

## Translations

* #14 - Add Spanish translation (Thanx, Ruddi!)
