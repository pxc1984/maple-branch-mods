# Dressmakers

"Craft and trade beautiful clothing items."

This Vintage Story mod adds recipes for vanilla clothing items
like shirts, trousers and shoes.

Most of the class specific clothes can be crafted by both the
tailor and the respective class. Common and survivor clothing
items can be crafted by anyone, the rest are all new tailor
specific recipes.

The recipes use items like needles, awls and colored thread
from Tailor's Delight.

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/dressmakers)
* You also need to install [Tailor's Delight](https://mods.vintagestory.at/tailors_delight)
* You also need to install [Expanded Matter](https://mods.vintagestory.at/em)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_dressmakers/-/releases)

Dressmakers has config lib support, to use it, you need install these two mods:

* [Config lib](https://mods.vintagestory.at/configlib) (You need at least 1.3.13)
* [ImGui lib](https://mods.vintagestory.at/imgui)

If these two mods are not installed, the extra recipes are all enabled by default.

# Installation

This mod should work in existing worlds and should also be removable without
any problems. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Configuration

If you change any of the settings in the `dressmakers.yaml` config file or via the
in-game GUI, you need to restart the server or reload the world for the settings
to become effective.

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

