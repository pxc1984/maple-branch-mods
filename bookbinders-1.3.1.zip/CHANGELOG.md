# v1.3.0 - 2025-03-02 - VS 1.20

## Compatibility With VS 1.20

* #40 - Fixes and adaptions for 1.20:
  - Leather references
  - Trader patches

# v1.2.0 - 2024-11-16 - More Features

## New Features

* #39 - Ink & Quills can be placed in shelves, bookshelves & display cases

# v1.1.1 - 2024-08-30 - Spanish Translation

## Translations

* #37 - Add Latin American Spanish translation (Thanks, Ruddi!)

# v1.1.0 - 2024-08-24 - Translations

## Tweaks

* #34 - Copying a VS schematic needs ink & quill

## Translations

* #33 - Translate "game:handbook-item-usage" for when EM is not present
* #32 - Add Japanese translation (Thanks, Macoto Hino!)
* #31 - Add Ukrainian translation (Thanks, DeanBro!)

## Compatibility With Other Mods

* #35 - Better Ruins: blueprint copying can use Bookbinder's parchment and ink & quill variants
* #29 - Booktrader now also sells beeswax

# v1.0.0 - 2024-08-15 - Preamble

## New Features

* #26 - Add signatures for book binding
* #25 - Add vellum
* #24 - Add plain paper books without cover
* #11 - Add wet & dry papyrus strips and parchment made from papyrus
* #9 - Add bookbinding tool: bone and bamboo folders
* #5 - Add new book colors: black, darkblue, darkred & white
* #4 - Add different ink & quill variants: olivine, rose and smoky quartz
* #2 - Ink & Quill crafting needs quartz crystal

## Tweaks

* #25 - Craft small hide into vellum instead of parchment
* #22 - Book shelves need strips and nails & hammer to craft, can be upgraded
* #22 - Book shelves with 1 or 2 cross planks are crafted from empty book shelves
* #17 - **!!!! Parchment, books and scrolls are flammable !!!!**
* #15 - Rush matting from papyrus needs dry papyrus strips
* #14 - Legacy book shelves are in the new creative tab 'Library'
* #8 - Book crafting needs folder tools, twine, and a plain book
* #8 - Craft plain books from signatures
* #3 - Add books and ink and quill to a new creative menu tab "Library"

## Compatibility With Other Mods

* #27 - Add books and items to the Booktrader sell/buy list
* #26 - Tailor's Delight: Signature crafting needs needles
* #13 - Compatibility with Book Trader: Selling folding tools & papyrus strips
* #8 - Tailor's Delight: Book crafting needs folders and needles, too
* #7 - Wildcraft: Trees & Shrubs' black walnut dye can be used for ink
