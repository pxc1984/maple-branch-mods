This mod would have not been possible without the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bugreporting

### Translators

* English advisors: **Ashantin**, **jjallie1**
* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**
* Spanish: **Ruddi**
* Ukrainian: **DeanBro**

### Modding help

* All the people answering questions, on the modding-help discord channel or elsewere: You are awesome!
Especially:
  + **JapanHasRice**
  + **SpearAndFang**
  + **Vinter Night**

### Resources

The background image is from [Wikipedia](https://en.wikipedia.org/wiki/File:Domesday-book-1804x972.jpg)

