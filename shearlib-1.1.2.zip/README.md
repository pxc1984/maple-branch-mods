# ShearLib

"Harvest items from living animals."

This Vintage Story mod adds a behaviour to harvest items from live entities
with shears or a knife.

The code was provided by **Catasteroid**.

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/shearlib)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_shearlib/-/releases)

# Installation

This mod itself does not do anything, you need a mod that uses it, f.i. **Wool && More**.

This mod should work in existing worlds. If in doubt, please create a new world.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

