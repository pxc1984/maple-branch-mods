# v1.5.0 - 2025-01-20 - VS 1.20

## New Features

* #64 - Miner clothes can be crafted by anyone with the "hardy" trait like Blackguards
* #56 - Add missing recipe for noble and royal fur collar
* #54 - Add recipes for Nadiyan aprons, belts, boots & shoes, gloves and shirts

## Compatibility

* #59 - Fix clothing patches for 1.20
* #57 - Remove compatibility for Hide & Fabric (use Wool & More and Hunter's Lodge instead)
* #53 - Fixes for VS 1.20

## Translations

* #48 - Add Latin American Spanish translation (Thank you, Ruddi!)

## Balancing and Tweaking

* #65 - Use dark cloth and twine in recipes
* #60 - Use sturdy leather for sturdy and heavy leather items
* #60 - Nadiyan recipes use nadiyan leather as ingredient

# v1.4.0 - 2024-08-06 - Lost Recipes

## New Features

* #44 - Add more missing recipes for VS clothing (Thanx, anyanana!):
  - aristocrat leggings
  - barber surgeon handwraps
  - blackguard leggings
  - noble fillet
  - tailor blouse
  - tailor jacket
  - hunter leggings
  - woolen leggings (only with Hide & Fabric)

## Balancing and Tweaking

* #46 - Tweak pastoral pants with wool/cotton to include leather
* #45 - Tweak barber surgeon pants recipe to better match colors

# v1.3.1 - 2024-07-01 - Gilded Threads

## New Features

* #43 - Add recipe for deep noble leggings
* #42 - Use silver twine in recipes
* #41 - Replace gold nuggets with gilded (golden) twine in recipes

# v1.3.0 - 2024-07-22 - Warm Clothes

## New Features

* #40 - Add recipe for noble shirt
* #39 - Add recipe for pearl shirt
* #37 - Add recipe for prince breeches
* #36 - Add recipe for gem encrusted fur hat
* #35 - Add recipe for embroidered coif
* #34 - Add recipe for hunter shirt
* #33 - Add warmth to more vanilla craftable clothing items

## Balancing and Tweaking

* #30 - Increase buying prices for some expensive clothing items

## Compatibility With Other Mods

* #38 - Add compatibility with Geology Addons (use Ruby in crafting)

# v1.2.1 - 2024-07-02 - Thick Leather

## Balancing and Tweaking

* #32 - Replace thin leather with plain leather in crafting recipes

# v1.2.0 - 2024-06-18 - Hide and Fabric

## Balancing and Tweaking

* #21 - Shepherd clothing and sandals are now craftable by anyone

## New Features

* #20 - Add recipe for Merchant shirt
* #19 - Add config setting to disable Hide and Fabric recipes for VS clothing

## Compatibility With Other Mods

* #16 - Add 78 more VS clothing recipes based on Hide & Fabric cotton & wool

# v1.1.0 - 2024-06-05 - Stay Warm

## New Features

* #18 - Some leather boots use leather strips instead of twine
* #17 - Add commoner over coat recipe
* #13 - Add clockmaker wristguard recipe

## Bugfixes

* #13 - Fix clockmaker apron "tinker trait" recipe variant display

## Translations

* #9 - Add Japanese translation (Thank you, Macoto Hino!)

## Compatibility With Other Mods

* #14 - Add more VS fur clothing recipes based on Hide & Fabric hide
* #13 - Compatibility with Beltcraft
* #8 - Add more VS clothing recipes based on Hide & Fabric wool

# v1.0.0 - 2024-05-24 - Dresses to Kill

## New Features

* #4 - Add config lib support: Enable/disable recipes via config file
       Needs at least config lib 1.3.13 to work properly
* #3 - Add 105 recipes for VS generic clothing items
* #2 - Add 72 recipes for 41 unique VS class specific clothing items

## Compatibility With Other Mods

* #5 - Add recipes for Shepherd clothing using Hide & Fabric wool

