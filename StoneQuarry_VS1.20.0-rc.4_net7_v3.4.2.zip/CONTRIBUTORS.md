### WraithHunter
Is the author of the original [Quarry Works!](https://mods.vintagestory.at/show/mod/44) mod for 1.14.<br/>
Stone Quarry has come a long way since then, but without him it would never exist.

### Supporters on Patreon
- Tyron
- David Feldenkris

### Translators
- makoto_hino - Japanese translator
- Mayadzuko - Russian translator (guides)
- Aimli - Chinese translator
- purple8cloud - Korean translator
- All translators from [Vintage Story Mods](https://crowdin.com/project/vintage-story-mods) Crowdin

And also NiclAss and his Modder Companion, which helps me remember to read the comments on ModDB (:
